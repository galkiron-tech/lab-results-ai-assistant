"""MedExplain AI - core application package.

Modules:
    models        - lightweight data classes (Patient, LabResult, ...)
    data_loader   - loads JSON medical knowledge and scenarios from disk
    classifier    - deterministic rule-based lab value classification
    explainer     - non-diagnostic patient-facing explanations
    questions     - scenario-specific "ask your physician" question lists
    summary       - aggregated, non-diagnostic patient summary
    ui_components - Streamlit UI building blocks (RTL, cards, tables)
"""
